CREATE TABLE Prod_Test  (
UpDown BOOLEAN,
StartTime TIMESTAMP,
EndTime TIMESTAMP,
ReasonCodeInt INT,
ReasonCode VARCHAR,
Notes VARCHAR,
Updated TIMESTAMP,
Energy FLOAT
)
;
CREATE TABLE Part_Test  (
Part BOOLEAN,
StartTime TIMESTAMP,
EndTime TIMESTAMP,
PartCodeInt INT,
PartCode VARCHAR,
Notes VARCHAR,
Updated TIMESTAMP,
Energy FLOAT
)

