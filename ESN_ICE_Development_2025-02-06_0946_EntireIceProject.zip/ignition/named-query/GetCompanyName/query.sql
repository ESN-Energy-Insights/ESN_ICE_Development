select company_name from company
where mqtt_topic = :companyID